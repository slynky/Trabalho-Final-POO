package org.teiacoltec.poo.tp3;

import java.io.*;

public class Serializacao {

    public static void salvarObjeto(Object obj, String caminho) throws IOException {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(caminho))) {
            oos.writeObject(obj);
        }
    }

    public static Object carregarObjeto(String caminho) throws IOException, ClassNotFoundException {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(caminho))) {
            return ois.readObject();
        }
    }
}