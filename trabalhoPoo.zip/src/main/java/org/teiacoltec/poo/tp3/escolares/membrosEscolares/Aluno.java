package org.teiacoltec.poo.tp3.escolares.membrosEscolares;

import org.teiacoltec.poo.tp3.pessoa.Pessoa;
import java.io.Serializable;

public class Aluno extends Pessoa implements Serializable{
    private static final long serialVersionUID = 1L;

    private String matricula;
    private String curso;

    public Aluno(String cpf, String nome, String nascimento, String email, String endereco, String matricula, String curso, String senha) {
        super(cpf, nome, nascimento, email, endereco, senha);
        this.matricula = matricula;
        this.curso = curso;
    }

    public Aluno(Aluno outro) {
        super(outro);
        this.matricula = outro.matricula;
        this.curso = outro.curso;
    }

    @Override
    public String obterInformacoes() {
        StringBuilder sb = new StringBuilder();
        sb.append("Aluno {\n");
        sb.append("Nome: ").append(nome).append("\n");
        sb.append("CPF: ").append(cpf).append("\n");
        sb.append("Nascimento: ").append(nascimento).append("\n");
        sb.append("Email: ").append(email).append("\n");
        sb.append("Endereço: ").append(endereco).append("\n");
        sb.append("Matrícula: ").append(matricula).append("\n");
        sb.append("Curso: ").append(curso).append("\n");
        sb.append("}");
        return sb.toString();
    }

    public String getMatricula() {
        return matricula;
    }

    public String getCurso() {
        return curso;
    }

    @Override
    public String toString() {
        // Chama o toString() da classe Pessoa e adiciona os campos específicos de Aluno
        return "[Aluno] " + super.toString() + "Matrícula: " + this.matricula + "\n Curso: " + this.curso + "\n";
    }
}
