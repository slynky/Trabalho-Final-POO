package org.teiacoltec.poo.tp3.escolares.membrosEscolares;

import org.teiacoltec.poo.tp3.pessoa.Pessoa;
import java.io.Serializable;

public class Monitor extends Pessoa implements Serializable{
    private static final long serialVersionUID = 1L;

    private String matricula;
    private String curso;

    // Construtor para inicializar os atributos herdados e os específicos da classe
    public Monitor(String nome, String cpf, String dataNascimento, String email, String endereco, String matricula, String curso, String senha) {
        super(nome, cpf, dataNascimento, email, endereco, senha);
        this.matricula = matricula;
        this.curso = curso;
    }

    @Override
    public String toString() {
        return "[Monitor]: "+ super.toString() + "Matrícula: " + matricula + "\nCurso: " + curso + "\n";
    }

    // Getters e Setters para os atributos específicos
    public String getMatricula() {
        return matricula;
    }

    public String getCurso() {
        return curso;
    }
}