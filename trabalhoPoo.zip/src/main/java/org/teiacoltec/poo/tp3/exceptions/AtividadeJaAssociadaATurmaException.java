package org.teiacoltec.poo.tp3.exceptions;

public class AtividadeJaAssociadaATurmaException extends RuntimeException {
    public AtividadeJaAssociadaATurmaException(String message) {
        super(message);
    }
}
