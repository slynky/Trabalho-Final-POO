package org.teiacoltec.poo.tp3.exceptions;

public class AtividadeNaoAssociadaATurmaException extends RuntimeException {
    public AtividadeNaoAssociadaATurmaException(String message) {
        super(message);
    }
}
