package org.teiacoltec.poo.tp3.exceptions;

public class AtividadeNaoPertenceATurmaException extends RuntimeException {
    public AtividadeNaoPertenceATurmaException(String message) {
        super(message);
    }
}
