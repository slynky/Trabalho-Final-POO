package org.teiacoltec.poo.tp3.exceptions;

public class PessoaJaParticipanteException extends RuntimeException {
    public PessoaJaParticipanteException(String message) {
        super(message);
    }
}
