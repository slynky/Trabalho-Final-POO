package org.teiacoltec.poo.tp3.exceptions;

public class TarefaJaCriadaException extends RuntimeException {
    public TarefaJaCriadaException(String message) {
        super(message);
    }
}
