package org.teiacoltec.poo.tp3.exceptions;

public class TurmaNaoEncontradaException extends RuntimeException {
    public TurmaNaoEncontradaException(String message) {
        super(message);
    }
}
